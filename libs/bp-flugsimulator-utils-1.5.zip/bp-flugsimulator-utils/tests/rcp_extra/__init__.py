"""
Init file for rpc extra (test).
"""
